import './App.css';
import {useEffect, useState} from 'react';
import Page from "./comps/page";
import { faCrosshairs } from "@fortawesome/free-solid-svg-icons";

function App() {

  return (

    <div className="App">
      <Page />
    </div>

  );
}

export default App;
